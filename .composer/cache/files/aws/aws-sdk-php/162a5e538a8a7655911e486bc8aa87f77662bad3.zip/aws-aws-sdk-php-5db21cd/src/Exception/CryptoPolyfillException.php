<?php
namespace Aws\Exception;

/**
 * Class CryptoPolyfillException
 */
class CryptoPolyfillException extends \RuntimeException
{

}
