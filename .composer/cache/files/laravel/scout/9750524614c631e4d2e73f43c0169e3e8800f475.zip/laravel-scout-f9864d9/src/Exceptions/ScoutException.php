<?php

namespace Laravel\Scout\Exceptions;

use Exception;

class ScoutException extends Exception
{
    //
}
