Code tag in CKEditor
==============

![](http://imgur.com/LN0MAEZ.png)

Install by placing in ckeditor/plugins/ and add the following to ckeditor/config.js

    config.extraPlugins = 'codeTag';
