<?php

declare(strict_types=1);

namespace Gemini\Testing\Responses\Fixtures\Files;

final class UploadResponseFixture
{
    public const ATTRIBUTES = [
        'file' => MetadataResponseFixture::ATTRIBUTES,
    ];
}
