<?php

declare(strict_types=1);

namespace Gemini\Laravel\Testing;

use Gemini\Testing\ClientFake;

class GeminiFake extends ClientFake {}
